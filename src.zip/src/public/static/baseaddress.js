window.baseaddress = {
  env: {
      "BaseAddress":"https://CallCenterAnalyticsDummy/GGKAPI/Services/API/",
  }
}