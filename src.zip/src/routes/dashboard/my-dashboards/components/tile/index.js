import MyDashboardTable from './my-dashboard-table.component';

export default MyDashboardTable;