import Details from './details.component';

export default Details; 