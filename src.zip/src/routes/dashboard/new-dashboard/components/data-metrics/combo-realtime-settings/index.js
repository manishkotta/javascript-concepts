﻿import ComboRealTimeSettings from "./combo-realtime-settings.component"

export default ComboRealTimeSettings
