﻿import GridSettings from "./grid-settings.component"

export default GridSettings
