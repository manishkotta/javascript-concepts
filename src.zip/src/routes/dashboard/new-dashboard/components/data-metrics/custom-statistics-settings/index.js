﻿import CustomStatisticsSettings from "./custom-statistics-settings"

export default CustomStatisticsSettings
