﻿import DataMetrics from "./data-metrics.component"

export default DataMetrics
