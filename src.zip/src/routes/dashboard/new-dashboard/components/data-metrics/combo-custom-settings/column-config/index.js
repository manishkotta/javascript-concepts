﻿import ComboCustomColumns from "./column.component"

export default ComboCustomColumns
