﻿import ComboCustomSettings from "./combo-custom-settings.component"

export default ComboCustomSettings
