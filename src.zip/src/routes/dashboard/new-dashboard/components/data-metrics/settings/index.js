﻿import Settings from "./settings.component"

export default Settings
