import FiltersContainer from './filters.container';

export default FiltersContainer;