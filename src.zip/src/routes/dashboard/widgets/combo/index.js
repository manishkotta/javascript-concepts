import ComboWidget from './combo.component';

export default ComboWidget;
