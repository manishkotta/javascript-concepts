import WidgetHeader from './widget-header.component';

export default WidgetHeader;