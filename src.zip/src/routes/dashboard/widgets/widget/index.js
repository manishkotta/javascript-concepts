// import WidgetContainer from "./widget.container";

// export default WidgetContainer;
import Widget from './widget.component';

export default Widget;