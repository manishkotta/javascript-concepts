import CircularProgressComponent from './circular-progress-widget.component';

export default CircularProgressComponent;
