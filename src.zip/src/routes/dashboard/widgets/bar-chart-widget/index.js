import BarChartWidget from './bar-chart-widget.component';

export default BarChartWidget;