import BoxWidget from './box-widget.component';

export default BoxWidget;
