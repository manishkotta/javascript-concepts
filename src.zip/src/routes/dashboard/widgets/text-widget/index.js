import TextWidget from './text-widget.component';

export default TextWidget;
