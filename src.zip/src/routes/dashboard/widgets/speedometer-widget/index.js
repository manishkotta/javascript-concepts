import SpeedoWidget from './speedo.component';

export default SpeedoWidget;