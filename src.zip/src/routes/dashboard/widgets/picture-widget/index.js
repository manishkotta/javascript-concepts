import PictureWidget from './picture-widget.component';

export default PictureWidget;
