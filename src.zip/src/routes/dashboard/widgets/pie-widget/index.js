import PieWidget from './pie-widget.component';

export default PieWidget;