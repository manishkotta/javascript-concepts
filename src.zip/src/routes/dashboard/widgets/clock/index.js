import ClockWidget from './clock-widget.component';

export default ClockWidget;
