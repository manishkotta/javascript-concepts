import ProgressBarWidget from'./progress-bar-widget.component'

export default ProgressBarWidget;