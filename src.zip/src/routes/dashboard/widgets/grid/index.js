import GridWidget from './grid.component';

export default GridWidget;
