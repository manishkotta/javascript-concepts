import Dashboard from './dashboard.component';

export default Dashboard;