import _ from './lib/Select';
export default _;