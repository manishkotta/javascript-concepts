import ColorPicker from "./color-picker";

export default ColorPicker;