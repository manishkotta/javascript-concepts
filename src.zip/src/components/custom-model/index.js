import CustomModal from './custom-model.component';

export default CustomModal;