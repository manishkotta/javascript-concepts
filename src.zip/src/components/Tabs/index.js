import TabsLayout from './TabsLayout'

export default TabsLayout
