import SpeedoStyles from './speedo-styles.component';

export default SpeedoStyles;