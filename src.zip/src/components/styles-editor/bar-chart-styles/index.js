import BarChartStyles from './bar-chart-styles.component';

export default BarChartStyles;