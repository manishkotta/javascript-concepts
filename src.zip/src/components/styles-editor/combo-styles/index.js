import ComboStyles from './combo-styles.component';

export default ComboStyles;