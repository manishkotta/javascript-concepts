import TextStyles from './text-styles.component';

export default TextStyles;