import PieStyles from './pie-styles.component';

export default PieStyles;