import PictureStyles from './picture-styles.component';

export default PictureStyles;