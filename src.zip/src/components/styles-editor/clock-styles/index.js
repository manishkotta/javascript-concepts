﻿import ClockStyles from './clock-styles.component';

export default ClockStyles;