import EditorContainer from './styles-editor.container';

export default EditorContainer;