import ProgressBarStyles from './progress-bar-styles.component';

export default ProgressBarStyles;