import BoxStyles from './box-styles.component';

export default BoxStyles;