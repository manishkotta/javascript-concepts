import CircularProgressStyles from './circular-progress-styles';

export default CircularProgressStyles;