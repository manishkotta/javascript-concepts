﻿import NotificationContainer from './notification.container';

export default NotificationContainer;