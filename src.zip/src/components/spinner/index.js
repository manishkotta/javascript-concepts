import SpinnerContainer from './spinner.container';

export default SpinnerContainer;