import CheckBoxTree from './check-box-tree-root.component';

export default CheckBoxTree;