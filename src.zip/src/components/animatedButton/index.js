﻿import AnimatedButton from './animatedButton'

export default AnimatedButton
