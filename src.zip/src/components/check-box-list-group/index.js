import CheckBoxListGroup from './check-box-list-group.component';

export default CheckBoxListGroup;