import DragAndDropTable from './drag-and-drop-table';

export default DragAndDropTable;