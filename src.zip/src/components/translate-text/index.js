import T from "./translate-text";

export default T