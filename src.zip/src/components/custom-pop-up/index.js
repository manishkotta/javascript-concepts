import CustomPopUp from "./custom-pop-up";

export default CustomPopUp;