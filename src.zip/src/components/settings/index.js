import SettingsContainer from "./settings.container"

export default SettingsContainer
