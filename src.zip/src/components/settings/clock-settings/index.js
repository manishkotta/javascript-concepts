﻿import ClockSettingsContainer from './clock-settings.container';

export default ClockSettingsContainer;