import CustomModalPopUp from "./custom-modal-popup";

export default CustomModalPopUp;