import ToggleSwitch from './toggle-switch.component';

export default ToggleSwitch;