import RadioButtonGroup from './radio-button-group.component';

export default RadioButtonGroup;