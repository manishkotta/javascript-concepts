import CustomSelect from './custom-dropdown.component';

export default CustomSelect;