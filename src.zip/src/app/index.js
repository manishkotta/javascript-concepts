import AppContainer from './app.container';

export default AppContainer;